//
//  information.swift
//  Torneio
//
//  Created by Student11 on 22/09/23.
//

import SwiftUI

struct Information: View {
    @StateObject var viewModel = SwiftUIView()
    var p : Campeonato
    var body: some View {
        ZStack {
            Color(.black)
            ignoresSafeArea()
            
            VStack {
                AsyncImage(url: URL (string: "\(p.imagemCampeonato!)")) { image in
                    image.resizable()
                        .ignoresSafeArea()
                        .frame(width: 800, height: 800)
                        .shadow(radius: 15)
                        .blur(radius: 10)
                } placeholder: {
                    ProgressView()
                }
                Text("É um campeonato de CSGO mt bom que os kra se enfrentam igual qualquer outro campeonato de Counter Strike Global Offensive")
                    .font(.headline)
            }
            
        }
    }
}

//struct information_Previews: PreviewProvider {
//    static var previews: some View {
//        Information()
//    }
//}
