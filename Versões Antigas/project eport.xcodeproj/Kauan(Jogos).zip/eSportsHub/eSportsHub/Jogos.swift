import SwiftUI

struct Jogos: View {
    @StateObject var api = ViewModel()
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.black)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                    }
                    Spacer(minLength: 50)
                    Text("Jogos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                    Spacer()
                    ScrollView(showsIndicators: false) {
                        ForEach(api.courses, id: \.self) { jogos in
                            NavigationLink(destination:  JogosClicou()) {
                                HStack {
                                    AsyncImage(url: URL(string: jogos.foto!)) { image in
                                        image.resizable()
                                    } placeholder: {
                                        ProgressView()
                                    }
                                    .frame(width: 125, height: 125)
                                    
                                    Text(jogos.nome!)
                                }
                            }
                        }
                        
                    }
                }.onAppear(){
                    api.fetch()
                }
            }
        }
    }
}
