import Foundation

struct Course: Hashable, Decodable{
    let nome : String?
    let desenvolvedora : String?
    let descricao : String?
    let foto : String?
    
}

class ViewModel: ObservableObject{
    @Published var courses: [Course] = []
    func fetch(){
        guard let url = URL(string: "http://127.0.0.1:1880/kfmREAD") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do{
                let parsed = try JSONDecoder().decode([Course].self, from: data)
                
                DispatchQueue.main.async {
                    self?.courses = parsed
                }
                
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
}



