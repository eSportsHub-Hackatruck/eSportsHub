//
//  ContentView.swift
//  eSportsHub
//
//  Created by Student14 on 22/09/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            VStack{
                TabView{
                    Home()
                        .tabItem{
                            Label("Home", systemImage: "house.fill")
                        }
                        .toolbar(.visible, for: .tabBar)
                        .toolbarBackground(Color.white, for: .tabBar)
                    Jogos()
                        .tabItem{
                            Label("Jogos", systemImage: "gamecontroller.fill")
                        }
                        .toolbar(.visible, for: .tabBar)
                        .toolbarBackground(Color.white, for: .tabBar)
                    Jogadores()
                        .tabItem{
                            Label("Jogadores", systemImage: "person.fill")
                        }
                        .toolbar(.visible, for: .tabBar)
                        .toolbarBackground(Color.white, for: .tabBar)
                    Times()
                        .tabItem{
                            Label("Times", systemImage: "shield.fill")
                        }
                        .toolbar(.visible, for: .tabBar)
                        .toolbarBackground(Color.white, for: .tabBar)
                    Torneios()
                        .tabItem{
                            Label("Torneios", systemImage: "trophy.fill")
                        }
                        .toolbar(.visible, for: .tabBar)
                        .toolbarBackground(Color.white, for: .tabBar)
                }
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
