//
//  Torneios.swift
//  eSportsHub
//
//  Created by Student14 on 22/09/23.
//

import SwiftUI

struct Torneios: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.black)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                    }
                    Spacer()
                    
                    
                }
            }
        }
    }
}

struct Torneios_Previews: PreviewProvider {
    static var previews: some View {
        Torneios()
    }
}
