//
//  JogosClicou.swift
//  eSportsHub
//
//  Created by Student14 on 22/09/23.
//

import SwiftUI

struct JogosClicou: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct JogosClicou_Previews: PreviewProvider {
    static var previews: some View {
        JogosClicou()
    }
}
