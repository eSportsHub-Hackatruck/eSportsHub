//
//  ContentView.swift
//  Torneio
//
//  Created by Student11 on 22/09/23.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = APILiga()
    
    var body: some View {
        
        NavigationStack {
            
            ZStack {
                Color(.black)
                    .ignoresSafeArea()
                VStack {
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .foregroundColor(.white)
                            .font(.title3)
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                    }
                    .padding(1)
                    Text("Campeonatos: CSGO")
                        .foregroundColor(.white)
                        .font(.largeTitle)
                    
                    
                    ScrollView{
                        ForEach(viewModel.campeonato, id: \.id){ index in
                            NavigationLink(destination: information(p: index)){
                                HStack {
                                    
                                    AsyncImage(url: URL (string: "\(index.imagemCampeonato!)")) { image in
                                        image
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 50)
                                    } placeholder: {
                                        ProgressView()
                                    }
                                    
                                    Text(index.nomeCampeonato!)
                                        .frame(width: 150, height: 50)
                                        .font(.title3)
                                        .foregroundColor(.black)
                                    
                                    
                                }.padding()
                                    .background(.gray)
                                    .foregroundColor(.black)
                                    .font(.headline)
                                    .cornerRadius(10)
                            }
                            
                            
                        }
                    }
                }
                }
                
                
            }.onAppear(){
                viewModel.fetch()
            
        }
    }
}
//                TabView{
//                                    Home()
//                                        .tabItem{
//                                            Label("Home", systemImage: "house.fill")
//                                        }
//                                    Jogos()
//                                        .tabItem{
//                                            Label("Jogos", systemImage: "gamecontroller.fill")
//                                        }
//                                    Jogadores()
//                                        .tabItem{
//                                            Label("Jogadores", systemImage: "person.fill")
//                                        }
//                                    Times()
//                                        .tabItem{
//                                            Label("Times", systemImage: "shield.fill")
//                                        }
//                                    Torneios()
//                                        .tabItem{
//                                            Label("Torneios", systemImage: "trophy.fill")
//                                        }
//                                }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
