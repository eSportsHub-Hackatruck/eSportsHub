//
//  APILiga.swift
//  Torneio
//
//  Created by Student11 on 22/09/23.
import Foundation

struct Campeonato : Decodable,Identifiable {
    let id : Int?
    let nomeCampeonato :  String?
    let imagemCampeonato :  String?
    let logoCampeonato :  String?
    let descricaoCampeonato : String?
}

class APILiga : ObservableObject {
    @Published var campeonato : [Campeonato] = []
    
    func fetch(){
        guard let url = URL(string: "https://raw.githubusercontent.com/AndreVerasFernandes/HackatruckAPI/main/APILiga.json") else{
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([Campeonato].self, from: data)
                
                DispatchQueue.main.async {
                    self?.campeonato = parsed
                }
            }catch{
                print(error)
            }
        }
        
        task.resume()
    }
}
