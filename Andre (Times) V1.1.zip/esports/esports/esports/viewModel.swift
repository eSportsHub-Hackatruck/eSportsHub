//
//  viewModel.swift
//  esports
//
//  Created by Student on 22/09/23.
//

import SwiftUI



struct teams: Codable, Identifiable{
    let id : Int?
    let nomeTime : String
    let img : String
    let corPrimario : String
    let corSecundario : String
   
}

class ViewModel : ObservableObject {
    @Published var Time : [teams] = []

    
    func fetch(){
        guard let url = URL(string: "https://raw.githubusercontent.com/AndreVerasFernandes/HackatruckAPI/main/APITime.json" ) else{
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
                guard let data = data, error == nil else{
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode([teams].self, from: data)
                
                DispatchQueue.main.async {
                    self?.Time = parsed
                }
            }catch{
                print(error)
            }
        }
        
        task.resume()
    }
}


//
