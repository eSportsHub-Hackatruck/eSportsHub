//
//  timeDesc.swift
//  esports
//
//  Created by Student on 22/09/23.
//

import SwiftUI

struct timeDesc: View {
    @Binding var Selecttime: teams

    var body: some View {
        Text("\(Selecttime.nomeTime)")
    }
}

struct timeDesc_Previews: PreviewProvider {
    static var previews: some View {
        timeDesc(Selecttime: $Selecttime )
    }
}
