import Foundation

struct Jogo: Hashable, Decodable{
    let nome : String?
    let desenvolvedora : String?
    let descricao : String?
    let foto : String?
    
}

class ViewModel: ObservableObject{
    @Published var jogos: [Jogo] = []
    func fetch(){
        guard let url = URL(string: "http://127.0.0.1:1880/kfmREAD") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do{
                let parsed = try JSONDecoder().decode([Jogo].self, from: data)
                
                DispatchQueue.main.async {
                    self?.jogos = parsed
                }
                
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
}



struct Jogador: Hashable, Decodable{
    
    let nickJogador: String?
    let nameJogador: String?
    let countryJogador: String?
    let countryPhotoJogador: String?
    let birthdayJogador: String?
    let photoJogador: String?
    let teamJogador: String?
    let teamPhotoJogador: String?
}

class api: ObservableObject{
    @Published var jogadores: [Jogador] = []
    func fetch(){
        guard let url = URL(string: "http://192.168.128.240:1880/eSportHubJogadorREAD") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do{
                let parsed = try JSONDecoder().decode([Jogador].self, from: data)
                
                DispatchQueue.main.async {
                    self?.jogadores = parsed
                }
                
            }
            catch{
                print(error)
            }
        }
        task.resume()
    }
}


