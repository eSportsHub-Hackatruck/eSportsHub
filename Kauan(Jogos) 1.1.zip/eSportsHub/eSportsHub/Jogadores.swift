//
//  Jogadores.swift
//  eSportsHub
//
//  Created by Student14 on 22/09/23.
//

import SwiftUI

struct Jogadores: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.black)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .colorInvert()
                    }
                    Spacer()
                    
                    
                    
                }
            }
        }
    }
}

struct Jogadores_Previews: PreviewProvider {
    static var previews: some View {
        Jogadores()
    }
}
