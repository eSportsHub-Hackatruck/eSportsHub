//
//  JogadoresClicou.swift
//  eSportsHub
//
//  Created by Student14 on 25/09/23.
//

import SwiftUI

struct JogadoresClicou: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct JogadoresClicou_Previews: PreviewProvider {
    static var previews: some View {
        JogadoresClicou()
    }
}
