//
//  eSportsHubApp.swift
//  eSportsHub
//
//  Created by Student14 on 22/09/23.
//

import SwiftUI

@main
struct eSportsHubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
