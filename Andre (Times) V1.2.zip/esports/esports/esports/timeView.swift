//
//  timeView.swift
//  esports
//
//  Created by Student on 22/09/23.
//

import SwiftUI

struct timeView: View {
    @StateObject var viewModel = ViewModel()
    @State var Timeselect: teams = teams(id : nil,
                                         nomeTime : "",
                                         img : "",
                                         corPrimario : "",
                                         corSecundario : "")
    var body: some View {
        NavigationStack{
            ZStack{
                Color.black
                    .ignoresSafeArea()
                VStack {
                    ScrollView(.vertical){
                        ForEach(viewModel.Time){ index in
                            HStack{
                                NavigationLink (destination: timeDesc(Timeselect: index) )   {
                                                AsyncImage(url: URL(string: "\(index.img)"))
                                                { image in image.resizable() } placeholder: { Color.gray } .frame(width: 50, height: 50)
                                                
                                                Text("\(index.nomeTime)")
                                                    .frame(width: 150, height: 50)        .font(.title3)
                                                    .foregroundColor(.black)
                                            }
                                            .padding()
                                            .background(.gray)
                                            .foregroundColor(.black
                                    )
                                            .font(.headline)
                                            .cornerRadius(10)
                                            
                            }
                        }
                    }
                } .onAppear(){
                    viewModel.fetch()
                    
                }
            }
        }
    }
        
        struct timeView_Previews: PreviewProvider {
            static var previews: some View {
                timeView()
            }
        }
}

