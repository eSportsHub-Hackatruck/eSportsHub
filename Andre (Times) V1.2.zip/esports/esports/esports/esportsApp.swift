//
//  esportsApp.swift
//  esports
//
//  Created by Student on 22/09/23.
//

import SwiftUI

@main
struct esportsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
