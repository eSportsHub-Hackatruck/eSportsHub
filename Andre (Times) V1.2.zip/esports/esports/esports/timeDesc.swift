//
//  timeDesc.swift
//  esports
//
//  Created by Student on 25/09/23.
//

import SwiftUI

struct timeDesc: View {
    @StateObject var viewModel = ViewModel()
    var Timeselect: teams
    var body: some View {
        ZStack{ Color.black
                .ignoresSafeArea()
            VStack{
                Text("\(Timeselect.nomeTime)")
                    .colorInvert()
                    .font(.title)
                    .bold()
                    .padding()
                
                ScrollView(.vertical) {
                    AsyncImage(url: URL(string: "\(Timeselect.img)")) { image in image.resizable().frame(width: 100, height: 100) } placeholder: { Color.gray }
                    
                        .frame(width: 150, height: 150) .clipShape(Circle())
                    .overlay {
                        Circle().stroke(.white, lineWidth: 4)
                    }
                    .shadow(radius: 7)
                    .background(Circle().fill(.gray))
                
                
                
                
                Text("Players")
                    .colorInvert()
                    .font(.title)
                    .bold()
                    .padding()
                    
                    
            }
            }
        } .onAppear(){
            viewModel.fetch()}
    }
}

struct timeDesc_Previews: PreviewProvider {
    @State static var Timeselect: teams = teams(id : nil,
                                         nomeTime : "",
                                         img : "",
                                         corPrimario : "",
                                         corSecundario : "")
    static var previews: some View {
        timeDesc(Timeselect: Timeselect)
    }
}


