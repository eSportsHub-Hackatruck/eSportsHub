//
//  ContentView.swift
//  esports
//
//  Created by Student on 22/09/23.
//

import SwiftUI

struct ContentView: View {
    @State private var searchText = ""
    @State private var searchIsActive = false

    var body: some View {
        NavigationStack {
            ZStack {
                VStack { 
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 25))
                            .foregroundColor(Color.white)
                    }
                    TabView {
                        casaView()
                            .tabItem {
                                Label("", systemImage: "house.fill")
                            }
                        jogoView()
                            .tabItem {
                                Label("", systemImage: "gamecontroller.fill")
                            }
                        jogadorView()
                            .tabItem {
                                Label("", systemImage: "person.fill")
                            }
                        timeView()
                            .tabItem {
                                Label("", systemImage: "shield.fill" )
                            }
                        
                        trofeuView()
                            .tabItem {
                                Label("", systemImage: "trophy.fill")
                            }
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
