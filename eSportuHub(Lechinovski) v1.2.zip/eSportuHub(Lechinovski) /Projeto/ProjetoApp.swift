//
//  ProjetoApp.swift
//  Projeto
//
//  Created by Student09 on 21/09/23.
//

import SwiftUI

@main
struct ProjetoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
