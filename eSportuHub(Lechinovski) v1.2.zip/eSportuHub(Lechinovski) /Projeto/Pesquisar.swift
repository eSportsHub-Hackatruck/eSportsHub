//
//  Pesquisar.swift
//  Projeto
//
//  Created by Student09 on 26/09/23.
//

import SwiftUI

struct Pesquisar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Pesquisar_Previews: PreviewProvider {
    static var previews: some View {
        Pesquisar()
    }
}
