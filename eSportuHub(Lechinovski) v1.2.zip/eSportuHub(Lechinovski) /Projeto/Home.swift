import SwiftUI

struct Home: View {
    var body: some View {
        ZStack{
            Color.black
                .edgesIgnoringSafeArea(.all)
            VStack{
            }
        }
    }
}
