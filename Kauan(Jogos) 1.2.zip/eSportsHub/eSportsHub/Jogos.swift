import SwiftUI

struct Jogos: View {
    @StateObject var api = ViewModel()
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.black)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    HStack {
                        Image(systemName: "gamecontroller.fill")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40))
                        Text("eSportsHub")
                            .fontWeight(.bold)
                            .foregroundColor(Color.white)
                        Spacer()
                        NavigationLink(destination: Pesquisar()){
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(Color.white)
                        }
                    }
                    Spacer(minLength: 20)
                    Text("Jogos")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                    Spacer()
                     
                    ScrollView(showsIndicators: false) {
                        ForEach(api.jogos, id: \.self) { jogos in
                            NavigationLink(destination:  JogosClicou(j: jogos)) {
                                HStack {
                                    SVGImage(url: URL(string: jogos.foto!)!, size: CGSize(width: 125,height: 125))
                                    .frame(width: 70, height: 70)
                                    
                                    Text(jogos.nome!)
                                        .fontWeight(.bold)
                                        .frame(width: 270, height: 50)
                                        .foregroundColor(Color.white)
                                }
                                .background(Color.gray)
                                .cornerRadius(20)
                                .padding(3)
                            }
                        }
                        
                    }
                }.onAppear(){
                    api.fetch()
                }
            }
        }
    }
}
