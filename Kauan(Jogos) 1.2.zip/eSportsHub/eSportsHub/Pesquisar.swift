import SwiftUI

struct Pesquisar: View {
    @State private var text = ""
    @StateObject var Api = api()
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.black)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Text("Pesquisar")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .fontWeight(.bold)
                    Spacer()
                    ScrollView {
                        VStack{
                            
                            ForEach(Api.jogadores, id: \.self) {jogador in
                                NavigationLink(destination: JogadorClicou(j: jogador)){
                                    HStack{
                                        
                                        AsyncImage(url: URL(string: jogador.photoJogador!)) { image in
                                            image.resizable()
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        .frame(width: 70, height: 70)
                                        
                                        Text(jogador.nickJogador!)
                                            .fontWeight(.bold)
                                            .frame(width: 270, height: 50)
                                            .foregroundColor(Color.white )
                                    }
                                    .background(Color.gray)
                                    .cornerRadius(20)
                                    .padding(3)
                                }
                            }
                            
                        }.onAppear{
                            Api.fetch()
                        }
                    }
                        .searchable(text: $text)
                        .foregroundColor(Color.white)
                }
            }
        }
    }
}

struct Pesquisar_Previews: PreviewProvider {
    static var previews: some View {
        Pesquisar()
    }
}
