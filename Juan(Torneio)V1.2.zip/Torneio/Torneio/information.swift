//
//  information.swift
//  Torneio
//
//  Created by Student11 on 22/09/23.
//

import SwiftUI

struct information: View {
    @StateObject var viewModel = APILiga()
    var p : Campeonato
    var body: some View {
        ZStack {
            Color(.black)
            .ignoresSafeArea()
                VStack {
                    Text("\(p.nomeCampeonato!)")
                        .padding()
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    ScrollView {
                    AsyncImage(url: URL (string: "\(p.logoCampeonato!)")) { image2 in
                        image2
                            .resizable()

                            .clipShape(Circle())
                            .background(Circle().fill(Color("corDeFundo")))


                            .overlay {
                                Circle().stroke(.white, lineWidth: 4)
                            }
                            .shadow(radius: 15)
                            .frame(width: 250, height: 250)

                    } placeholder: {
                        ProgressView()
                    }
               
                    AsyncImage(url: URL (string: "https://cdn2.iconfinder.com/data/icons/popular-games-1/50/csgo_squircle-512.png")) { image2 in
                        image2
                            .resizable()
                            .clipShape(Circle())
                            .background(Circle().fill(.gray))
                            .frame(width: 75, height: 75)
                        
                            .overlay {
                                Circle().stroke(.white, lineWidth: 4)
                            }
                            .shadow(radius: 15)
                            
                            .offset(x: 100, y: -80)
                    } placeholder: {
                        ProgressView()
                    }
                  
                   
                        
                       
                   
           
                 
                        Text("\(p.descricaoCampeonato!)")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                    Spacer()
                }
            }
            
        }
        
    }
}

struct information_Previews: PreviewProvider {
    static var previews: some View {
        information( p: Campeonato(id: 40, nomeCampeonato: "ESL SPorts", imagemCampeonato: "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/53917b67-44dd-4908-b8b3-f586ad93d82c/dagn4ab-c7aca4cd-2da5-4a48-a8af-e16d79d33cd5.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzUzOTE3YjY3LTQ0ZGQtNDkwOC1iOGIzLWY1ODZhZDkzZDgyY1wvZGFnbjRhYi1jN2FjYTRjZC0yZGE1LTRhNDgtYThhZi1lMTZkNzlkMzNjZDUuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.WQ1Xd4bOtUa42tlRMgJK1nDCfbo1M198wiR0vFo8b_8",logoCampeonato: "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/53917b67-44dd-4908-b8b3-f586ad93d82c/dagn4ab-c7aca4cd-2da5-4a48-a8af-e16d79d33cd5.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzUzOTE3YjY3LTQ0ZGQtNDkwOC1iOGIzLWY1ODZhZDkzZDgyY1wvZGFnbjRhYi1jN2FjYTRjZC0yZGE1LTRhNDgtYThhZi1lMTZkNzlkMzNjZDUuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.WQ1Xd4bOtUa42tlRMgJK1nDCfbo1M198wiR0vFo8b_8", descricaoCampeonato: "Olá, aqui vai aparecer a descrição...") )
    }
}
