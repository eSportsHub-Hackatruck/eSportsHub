//
//  TorneioApp.swift
//  Torneio
//
//  Created by Student11 on 22/09/23.
//

import SwiftUI

@main
struct TorneioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
