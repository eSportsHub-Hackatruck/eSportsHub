import SwiftUI

struct Torneios: View {
    var body: some View {
        ZStack{
            Color.black
                .edgesIgnoringSafeArea(.all)
            VStack{
            }
        }
    }
}

struct Torneios_Previews: PreviewProvider {
    static var previews: some View {
        Torneios()
    }
}
