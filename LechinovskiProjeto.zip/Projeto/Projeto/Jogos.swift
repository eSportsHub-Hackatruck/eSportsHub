import SwiftUI

struct Jogos: View {
    var body: some View {
        ZStack{
            Color.black
                .edgesIgnoringSafeArea(.all)
            VStack{
            }
        }
    }
}
